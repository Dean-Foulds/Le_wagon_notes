def analyze(text)
  # TODO: should analyze the text, and return the result hash with all features
end